# ExifEYE
Image/Audio Exif metadata parser. Specifically looks for GPS location as well.
